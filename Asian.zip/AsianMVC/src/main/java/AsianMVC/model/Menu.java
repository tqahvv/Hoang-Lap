package AsianMVC.model;

public class Menu {
	private Integer menu_id;
	private String menu_name;
	private String url;
	private Integer parent_id;
	private Integer order;
	
	public Menu() {
		super();
	}

	public Menu(Integer menu_id, String menu_name, String url, Integer parent_id, Integer order) {
		this(menu_name, url, parent_id, order);
		this.menu_id = menu_id;		
	}
	
	public Menu(String menu_name, String url, Integer parent_id, Integer order) {	
		this.menu_name = menu_name;
		this.url = url;
		this.parent_id = parent_id;
		this.order = order;
	}

	public Integer getMenu_id() {
		return menu_id;
	}

	public void setMenu_id(Integer menu_id) {
		this.menu_id = menu_id;
	}

	public String getMenu_name() {
		return menu_name;
	}

	public void setMenu_name(String menu_name) {
		this.menu_name = menu_name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Integer getParent_id() {
		return parent_id;
	}

	public void setParent_id(Integer parent_id) {
		this.parent_id = parent_id;
	}

	public Integer getOrder() {
		return order;
	}

	public void setOrder(Integer order) {
		this.order = order;
	}

	@Override
	public String toString() {
		return "Menu [menu_id=" + menu_id + ", menu_name=" + menu_name + ", url=" + url + ", parent_id=" + parent_id
				+ ", order=" + order + "]";
	}
}
