package AsianMVC.model;

import javax.validation.constraints.NotBlank;

public class New {
	private Integer new_id;	
	@NotBlank(message = "Tiêu đề không được để trống")
	private String new_title;
	@NotBlank(message = "Hình ảnh không được để trống")
	private String new_image;
	@NotBlank(message = "Mô tả ngắn không được để trống")
	private String new_caption;
	@NotBlank(message = "Nôi dung không được để trống")
	private String new_content;
	private String new_hot;
	private String status;
	private Category category;
	
	public New() {
		super();
	}

	public New(Integer new_id, String new_title, String new_image, String new_caption,
			String new_content, String new_hot, String status, Category category) {
		this(new_title, new_image, new_caption, new_content, new_hot, status, category);
		this.new_id = new_id;		
	}
	
	public New(String new_title, String new_image, String new_caption,
			String new_content, String new_hot, String status, Category category) {				
		this.new_title = new_title;
		this.new_image = new_image;
		this.new_caption = new_caption;
		this.new_content = new_content;
		this.new_hot = new_hot;
		this.status = status;
		this.category = category;
	}

	public Integer getNew_id() {
		return new_id;
	}

	public void setNew_id(Integer new_id) {
		this.new_id = new_id;
	}

	public String getNew_title() {
		return new_title;
	}

	public void setNew_title(String new_title) {
		this.new_title = new_title;
	}

	public String getNew_image() {
		return new_image;
	}

	public void setNew_image(String new_image) {
		this.new_image = new_image;
	}

	public String getNew_caption() {
		return new_caption;
	}

	public void setNew_caption(String new_caption) {
		this.new_caption = new_caption;
	}

	public String getNew_content() {
		return new_content;
	}

	public void setNew_content(String new_content) {
		this.new_content = new_content;
	}

	public String getNew_hot() {
		return new_hot;
	}

	public void setNew_hot(String new_hot) {
		this.new_hot = new_hot;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "New [new_id=" + new_id + ", new_title=" + new_title + ", new_image=" + new_image + ", new_caption="
				+ new_caption + ", new_content=" + new_content + ", new_hot=" + new_hot + ", status=" + status
				+ ", category=" + category + "]";
	}

	
}
