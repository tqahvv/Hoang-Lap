package AsianMVC.model;

import java.sql.Date;

public class Comment {
	private Integer comment_id;
	private String name;
	private String email;
	private String comment;
	private Integer new_id;
	private Date created_date;
	private String status;
	private String new_title;
	private String new_image;

	public Comment() {
		super();
	}

	public Comment(Integer comment_id, String name, String email, String comment, Integer new_id, Date created_date, String status, String new_title, String new_image) {
		this(name, email, comment, new_id, created_date, status, new_title, new_image);
		this.comment_id = comment_id;		
	}
	
	public Comment(String name, String email, String comment, Integer new_id, Date created_date, String status, String new_title, String new_image) {		
		this.name = name;
		this.email = email;
		this.comment = comment;
		this.new_id = new_id;
		this.created_date = created_date;
		this.status = status;
		this.new_title = new_title;
		this.new_image = new_image;
	}

	public Integer getComment_id() {
		return comment_id;
	}

	public void setComment_id(Integer comment_id) {
		this.comment_id = comment_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Integer getNew_id() {
		return new_id;
	}

	public void setNew_id(Integer new_id) {
		this.new_id = new_id;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getNew_title() {
		return new_title;
	}

	public void setNew_title(String new_title) {
		this.new_title = new_title;
	}

	public String getNew_image() {
		return new_image;
	}

	public void setNew_image(String new_image) {
		this.new_image = new_image;
	}

	@Override
	public String toString() {
		return "Comment [comment_id=" + comment_id + ", name=" + name + ", email=" + email + ", comment=" + comment
				+ ", new_id=" + new_id + ", created_date=" + created_date + ", status=" + status + ", new_title="
				+ new_title + ", new_image=" + new_image + "]";
	}
}
