package AsianMVC.controller.admin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import AsianMVC.dao.Impl.MenuDAO;
import AsianMVC.model.Menu;

@Controller
public class MenuController {
	@Autowired
	private MenuDAO menuDAO;
	
	@RequestMapping(value = {"/admin/menu/index"})
	public ModelAndView menuIndex(ModelAndView model) {
		List<Menu> list = menuDAO.getAll();
		model.addObject("list", list);
		model.setViewName("/admin/menu/index");
		return model;
	}
	
	@RequestMapping(value = {"/admin/menu/create"}, method = RequestMethod.GET)
	public ModelAndView menuCreate(ModelAndView model) {
		Menu menu = new Menu();
		model.addObject("menu", menu);
		model.setViewName("/admin/menu/edit");
		return model;
	}
	
	@RequestMapping(value = {"/admin/menu/save"}, method = RequestMethod.POST)
	public ModelAndView menuSave(@ModelAttribute Menu menu) {
		if(menu.getMenu_id() == null) {
			menuDAO.save(menu);
		} else {
			menuDAO.update(menu);
		}
		
		return new ModelAndView("redirect:index");
	}
	
	@RequestMapping(value = {"/admin/menu/edit"}, method = RequestMethod.GET)
	public ModelAndView menuEdit(HttpServletRequest request) {
		String id = request.getParameter("id");
		int menu_id = Integer.parseInt(id);
		Menu menu = menuDAO.get(menu_id);
		ModelAndView model = new ModelAndView("admin/menu/edit");
		model.addObject("menu", menu);
		return model;
	}
	
	@RequestMapping(value = {"/admin/menu/delete"}, method = RequestMethod.GET)
	public ModelAndView menuDelete(@RequestParam Integer id) {
	    menuDAO.delete(id);
	    return new ModelAndView("redirect:index");
	}
	
	
}
