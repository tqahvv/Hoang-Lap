package AsianMVC.controller.admin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import AsianMVC.dao.Impl.NewDAO;
import AsianMVC.model.Category;
import AsianMVC.model.New;

@Controller
public class NewsController {
	@Autowired 
	private NewDAO newDAO;
	
	@RequestMapping(value = {"/admin/news/index"}, method = RequestMethod.GET)
	public ModelAndView newIndex(
	        ModelAndView model,
	        @RequestParam(value = "page", defaultValue = "1") int page,
	        @RequestParam(value = "category_id", required = false) Integer category_id,
	        @RequestParam(value = "keyword", required = false) String keyword) {

	    int pageSizeNew = 10;
	    List<New> listNew;

	    if (category_id != null && category_id > 0) { 
	        if (keyword != null && !keyword.isEmpty()) {
	            listNew = newDAO.getNewsByCategoryAndKeyword(page, pageSizeNew, category_id, keyword);
	        } else {
	            listNew = newDAO.getAll(page, pageSizeNew, category_id);
	        }
	    } else { 
	        if (keyword != null && !keyword.isEmpty()) {
	            listNew = newDAO.getNewsByKeyword(page, pageSizeNew, keyword);
	        } else {
	            listNew = newDAO.getAllNew(page, pageSizeNew);
	        }
	    }

	    int totalNew;
	    if (category_id != null && category_id > 0) {
	        if (keyword != null && !keyword.isEmpty()) {
	            totalNew = newDAO.getTotalNewsByCategoryAndKeyword(category_id, keyword);
	        } else {
	            totalNew = newDAO.getTotalNewByCategory(category_id);
	        }
	    } else {
	        if (keyword != null && !keyword.isEmpty()) {
	            totalNew = newDAO.getTotalNewsByKeyword(keyword);
	        } else {
	            totalNew = newDAO.getTotalNew();
	        }
	    }

	    int totalPages = (int) Math.ceil((double) totalNew / pageSizeNew);

	    model.addObject("listNew", listNew);
	    model.addObject("currentPage", page);
	    model.addObject("totalPages", totalPages);
	    model.addObject("category_id", category_id);
	    model.addObject("keyword", keyword);

	    List<Category> categories = newDAO.listCategory();
	    model.addObject("categories", categories);

	    model.setViewName("/admin/news/index");
	    return model;
	}

	
	@RequestMapping(value = {"/admin/news/create"}, method = RequestMethod.GET)
	public ModelAndView newsCreate(ModelAndView model) {
		New news = new New();
		List<Category> category = newDAO.listCategory();
		
		model.addObject("news", news);
		model.addObject("category", category);
		model.setViewName("/admin/news/edit");
		return model;
	}
	
	@RequestMapping(value = {"/admin/news/save"}, method = RequestMethod.POST)
	public ModelAndView newsSave(@ModelAttribute("news") @Valid New news, BindingResult bindingResult, ModelAndView model) {
		news.setStatus("Hiện");
		if (bindingResult.hasErrors()) {
	        model.setViewName("admin/news/edit");
	        return model;
	    }
	    if (news.getNew_id() == null) {
	        newDAO.save(news);
	    } else {
	        New existingNews = newDAO.get(news.getNew_id());

	        if (news.getCategory() == null || news.getCategory().getCategory_id() == null) {
	            news.setCategory(existingNews.getCategory());
	        }
	        if (news.getNew_image() == null || news.getNew_image().isEmpty()) {
	            news.setNew_image(existingNews.getNew_image());
	        }

	        newDAO.update(news);
	    }
	    return new ModelAndView("redirect:index");
	}

	@RequestMapping(value = {"/admin/news/edit"}, method = RequestMethod.GET)
	public ModelAndView newsEdit(HttpServletRequest request) {
		String id = request.getParameter("id");
		int new_id = Integer.parseInt(id);
		New news = newDAO.get(new_id);
		List<Category> category = newDAO.listCategory();
		
		ModelAndView model = new ModelAndView("admin/news/edit");
		model.addObject("news", news);
		model.addObject("category", category);
		return model;
	}
	
	@RequestMapping(value = {"/admin/news/delete"}, method = RequestMethod.GET)
	public ModelAndView deleteNew(@RequestParam Integer id) {
	    newDAO.delete(id);
	    return new ModelAndView("redirect:index");
	}
	
	@RequestMapping(value = "/admin/news/status", method = RequestMethod.POST)
	public String updateNewStatus(@RequestParam("new_id") int new_id,
	                                  @RequestParam("status") String status,
	                                  RedirectAttributes redirectAttributes) {
	    try {
	        newDAO.updateNewStatus(new_id, status);
	        redirectAttributes.addFlashAttribute("successMessage", "Cập nhật trạng thái thành công!");
	    } catch (Exception e) {
	        redirectAttributes.addFlashAttribute("errorMessage", "Cập nhật trạng thái thất bại!");
	    }
	    return "redirect:index";
	}
}
