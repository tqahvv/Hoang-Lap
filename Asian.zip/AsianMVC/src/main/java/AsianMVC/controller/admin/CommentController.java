package AsianMVC.controller.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import AsianMVC.dao.Impl.CommentDAO;
import AsianMVC.model.Comment;

@Controller
public class CommentController {
	@Autowired
	private CommentDAO commentDAO;
	
	@RequestMapping(value = {"/admin/comment/index"})
	public ModelAndView commentIndex(
	        ModelAndView model,
	        @RequestParam(value = "keyword", required = false) String keyword,
	        @RequestParam(value = "date", required = false) String date) {

	    List<Comment> list;

	    if (keyword != null && !keyword.isEmpty()) { 
	        if (date != null && !date.isEmpty()) {	            
	            list = commentDAO.getCategoryByKeywordAndDate(keyword, date);
	        } else {	            
	            list = commentDAO.getCategoryByKeyword(keyword);
	        }
	    } else { 
	        if (date != null && !date.isEmpty()) {	           
	            list = commentDAO.getCommentsByDate(date);
	        } else {	            
	            list = commentDAO.getAll();
	        }
	    }

	    model.addObject("list", list);
	    model.addObject("keyword", keyword);
	    model.addObject("date", date);
	    model.setViewName("/admin/comment/index");
	    return model;
	}

	
	@RequestMapping(value = {"/admin/comment/delete"}, method = RequestMethod.GET)
	public ModelAndView deleteNew(@RequestParam Integer id) {
	    commentDAO.deleteComment(id);
	    return new ModelAndView("redirect:index");
	}
	
	@RequestMapping(value = "/admin/comment/status", method = RequestMethod.POST)
	public String updateCommentStatus(@RequestParam("comment_id") int comment_id,
	                                  @RequestParam("status") String status,
	                                  RedirectAttributes redirectAttributes) {
	    try {
	        commentDAO.updateCommentStatus(comment_id, status);
	        redirectAttributes.addFlashAttribute("successMessage", "Cập nhật trạng thái thành công!");
	    } catch (Exception e) {
	        redirectAttributes.addFlashAttribute("errorMessage", "Cập nhật trạng thái thất bại!");
	    }
	    return "redirect:index";
	}
}
