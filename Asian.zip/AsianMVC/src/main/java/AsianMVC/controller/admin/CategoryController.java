package AsianMVC.controller.admin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import AsianMVC.dao.Impl.CategoryDAO;
import AsianMVC.model.Category;

@Controller
public class CategoryController {
	@Autowired
	private CategoryDAO categoryDAO;
	
	
	@RequestMapping(value = {"/admin/category/index"})
	public ModelAndView categoryIndex(ModelAndView model) {
		List<Category> list = categoryDAO.getAll();
		model.addObject("list", list);
		model.setViewName("/admin/category/index");
		return model;
	}
	
	@RequestMapping(value = {"/admin/category/create"}, method = RequestMethod.GET)
	public ModelAndView categoryCreate(ModelAndView model) {
		Category category = new Category();
		model.addObject("category", category);
		model.setViewName("/admin/category/edit");
		return model;
	}
	
	@RequestMapping(value = {"/admin/category/save"}, method = RequestMethod.POST)
	public ModelAndView categorySave(@ModelAttribute("category") @Valid Category category, BindingResult bindingResult, ModelAndView model) {
		if (bindingResult.hasErrors()) {
	        model.setViewName("admin/category/edit");
	        return model;
	    }
		if(category.getCategory_id() == null) {
			categoryDAO.save(category);
		} else {
			categoryDAO.update(category);
		}
		
		return new ModelAndView("redirect:index");
	}
	
	@RequestMapping(value = {"/admin/category/edit"}, method = RequestMethod.GET)
	public ModelAndView categoryEdit(HttpServletRequest request) {
		String id = request.getParameter("id");
		int category_id = Integer.parseInt(id);
		Category category = categoryDAO.get(category_id);
		ModelAndView model = new ModelAndView("admin/category/edit");
		model.addObject("category", category);
		return model;
	}
	
	@RequestMapping(value = {"/admin/category/delete"}, method = RequestMethod.GET)
	public ModelAndView deleteNew(@RequestParam Integer id) {
	    categoryDAO.delete(id);
	    return new ModelAndView("redirect:index");
	}
	
	
}
