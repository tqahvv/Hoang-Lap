package AsianMVC.controller.admin;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import AsianMVC.dao.Impl.NewDAO;
import AsianMVC.dao.Impl.UserDAO;
import AsianMVC.model.User;

@Controller
public class AdminController {
	@Autowired
	private UserDAO userDAO;
	
	@Autowired
	private NewDAO newDAO;

	@RequestMapping(value = "/admin/login", method = RequestMethod.GET)
	public ModelAndView loginPage(ModelAndView model) {
		model.setViewName("login");
		return model;
	}

	@RequestMapping(value = "/admin/login", method = RequestMethod.POST)
	public ModelAndView login(@RequestParam("user_name") String user_name, @RequestParam("password") String password,
			HttpSession session, ModelAndView model) {
		User user = userDAO.get(user_name);

		if (user != null && user.getPassword().equals(password)) {
			session.setAttribute("logUser", user);
			model.setViewName("redirect:/admin/index");
		} else {
			model.setViewName("login");
		}
		return model;
	}

	@RequestMapping(value = "/admin/index", method = RequestMethod.GET)
	public ModelAndView index(ModelAndView model, HttpSession session) {
		User logUser = (User) session.getAttribute("logUser");
		if (logUser == null) {
			model.setViewName("redirect:/admin/login");
			return model;
		}
		int totalNew = newDAO.getTotalNew();
		Map<String, Integer> newByCategory = newDAO.countNewByCategory();
		model.addObject("logUser", logUser);
		model.addObject("totalNew", totalNew);
		model.addObject("newByCategory", newByCategory);
		model.setViewName("admin/index");
		return model;
	}

	@RequestMapping(value = "/admin/logout", method = RequestMethod.GET)
	public ModelAndView logout(ModelAndView model, HttpSession session) {
		session.invalidate();
		model.setViewName("redirect:/admin/login");
		return model;
	}
		
}
