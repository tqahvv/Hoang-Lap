package AsianMVC.controller.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import AsianMVC.dao.Impl.MenuDAO;
import AsianMVC.dao.Impl.NewDAO;
import AsianMVC.model.Menu;
import AsianMVC.model.New;

@Controller
public class HomeController {
	
	 @Autowired
	  private MenuDAO menuDAO;
	 
	 @Autowired
	  private NewDAO newDAO;
	 
	 @RequestMapping(value = {"/", "/trang-chu"})
	 public ModelAndView Index(ModelAndView model, @RequestParam(value = "page", defaultValue = "1") int page) {
	     List<Menu> listMenu = menuDAO.getAll();
	     model.addObject("listMenu", listMenu);

	     int pageSizeNew = 3;
	     List<New> listSportNew = newDAO.getAll(page, pageSizeNew, 1);
	     List<New> listLawNew = newDAO.getAll(page, pageSizeNew, 2);
	     List<New> listHealthNew = newDAO.getAll(page, pageSizeNew, 3);
	     List<New> listEnterNew = newDAO.getAll(page, pageSizeNew, 4);
	     List<New> listLifeNew = newDAO.getAll(page, pageSizeNew, 5);
	     List<New> listMusicNew = newDAO.getAll(page, pageSizeNew, 6);
	     List<New> listCinemaNew = newDAO.getAll(page, pageSizeNew, 7);
	     List<New> listTravelNew = newDAO.getAll(page, pageSizeNew, 8);
	     model.addObject("listSportNew", listSportNew);
	     model.addObject("listLawNew", listLawNew);
	     model.addObject("listHealthNew", listHealthNew);
	     model.addObject("listEnterNew", listEnterNew);
	     model.addObject("listLifeNew", listLifeNew);
	     model.addObject("listMusicNew", listMusicNew);
	     model.addObject("listCinemaNew", listCinemaNew);
	     model.addObject("listTravelNew", listTravelNew);
	    
	     List<New> hotSportNew = newDAO.getHotNew(1); 
	     List<New> hotLawNew = newDAO.getHotNew(2); 
	     List<New> hotHealthNew = newDAO.getHotNew(3); 
	     List<New> hotEnterNew = newDAO.getHotNew(4);
	     List<New> hotLifeNew = newDAO.getHotNew(5);
	     List<New> hotMusicNew = newDAO.getHotNew(6);
	     List<New> hotCinemaNew = newDAO.getHotNew(7);
	     List<New> hotTravelNew = newDAO.getHotNew(8);
	     model.addObject("hotSportNew", hotSportNew);
	     model.addObject("hotLawNew", hotLawNew);
	     model.addObject("hotHealthNew", hotHealthNew);
	     model.addObject("hotEnterNew", hotEnterNew);
	     model.addObject("hotLifeNew", hotLifeNew);
	     model.addObject("hotMusicNew", hotMusicNew);
	     model.addObject("hotCinemaNew", hotCinemaNew);
	     model.addObject("hotTravelNew", hotTravelNew);
	     model.setViewName("user/index");
	     return model;
	 }
	 
	 @RequestMapping(value = {"/sport"})
	 public ModelAndView listSport(ModelAndView model, @RequestParam(value = "page", defaultValue = "1") int page) {
		 List<Menu> listMenu = menuDAO.getAll();
	     model.addObject("listMenu", listMenu);

	     int pageSizeNew = 3;
	     List<New> listSportNew = newDAO.getAll(page, pageSizeNew, 1);
	     model.addObject("listSportNew", listSportNew);
	     List<New> hotSportNew = newDAO.getHotNew(1); 
	     model.addObject("hotSportNew", hotSportNew);
	     model.setViewName("user/sport");
	     return model;
	 }

	 @RequestMapping(value = {"/entert"})
	 public ModelAndView listEnter(ModelAndView model, @RequestParam(value = "page", defaultValue = "1") int page) {
		 List<Menu> listMenu = menuDAO.getAll();
	     model.addObject("listMenu", listMenu);

	     int pageSizeNew = 3;
	     List<New> listEnterNew = newDAO.getAll(page, pageSizeNew, 4);
	     model.addObject("listEnterNew", listEnterNew);
	     List<New> hotEnterNew = newDAO.getHotNew(4); 
	     model.addObject("hotEnterNew", hotEnterNew);
	     model.setViewName("user/entertaiment");
	     return model;
	 }
	 
	 @RequestMapping(value = {"/law"})
	 public ModelAndView listLaw(ModelAndView model, @RequestParam(value = "page", defaultValue = "1") int page) {
		 List<Menu> listMenu = menuDAO.getAll();
	     model.addObject("listMenu", listMenu);

	     int pageSizeNew = 3;
	     List<New> listLawNew = newDAO.getAll(page, pageSizeNew, 2);
	     model.addObject("listLawNew", listLawNew);
	     List<New> hotLawNew = newDAO.getHotNew(2); 
	     model.addObject("hotLawNew", hotLawNew);
	     model.setViewName("user/law");
	     return model;
	 }
	 
	 @RequestMapping(value = {"/health"})
	 public ModelAndView listHealth(ModelAndView model, @RequestParam(value = "page", defaultValue = "1") int page) {
		 List<Menu> listMenu = menuDAO.getAll();
	     model.addObject("listMenu", listMenu);

	     int pageSizeNew = 3;
	     List<New> listHealthNew = newDAO.getAll(page, pageSizeNew, 3);
	     model.addObject("listHealthNew", listHealthNew);
	     List<New> hotHealthNew = newDAO.getHotNew(3); 
	     model.addObject("hotHealthNew", hotHealthNew);
	     model.setViewName("user/health");
	     return model;
	 }
	 
	 @RequestMapping(value = {"/life"})
	 public ModelAndView listLife(ModelAndView model, @RequestParam(value = "page", defaultValue = "1") int page) {
		 List<Menu> listMenu = menuDAO.getAll();
	     model.addObject("listMenu", listMenu);

	     int pageSizeNew = 3;
	     List<New> listLifeNew = newDAO.getAll(page, pageSizeNew, 5);
	     model.addObject("listLifeNew", listLifeNew);
	     List<New> hotLifeNew = newDAO.getHotNew(5); 
	     model.addObject("hotLifeNew", hotLifeNew);
	     model.setViewName("user/life");
	     return model;
	 }
	 
	 @RequestMapping(value = {"/music"})
	 public ModelAndView listMusic(ModelAndView model, @RequestParam(value = "page", defaultValue = "1") int page) {
		 List<Menu> listMenu = menuDAO.getAll();
	     model.addObject("listMenu", listMenu);

	     int pageSizeNew = 3;
	     List<New> listMusicNew = newDAO.getAll(page, pageSizeNew, 6);
	     model.addObject("listMusicNew", listMusicNew);
	     List<New> hotMusicNew = newDAO.getHotNew(6); 
	     model.addObject("hotMusicNew", hotMusicNew);
	     model.setViewName("user/music");
	     return model;
	 }
	 
	 @RequestMapping(value = {"/cinema"})
	 public ModelAndView listCinema(ModelAndView model, @RequestParam(value = "page", defaultValue = "1") int page) {
		 List<Menu> listMenu = menuDAO.getAll();
	     model.addObject("listMenu", listMenu);

	     int pageSizeNew = 3;
	     List<New> listCinemaNew = newDAO.getAll(page, pageSizeNew, 7);
	     model.addObject("listCinemaNew", listCinemaNew);
	     List<New> hotCinemaNew = newDAO.getHotNew(7); 
	     model.addObject("hotCinemaNew", hotCinemaNew);
	     model.setViewName("user/cinema");
	     return model;
	 }
	 
	 @RequestMapping(value = {"/travel"})
	 public ModelAndView listTravel(ModelAndView model, @RequestParam(value = "page", defaultValue = "1") int page) {
		 List<Menu> listMenu = menuDAO.getAll();
	     model.addObject("listMenu", listMenu);

	     int pageSizeNew = 3;
	     List<New> listTravelNew = newDAO.getAll(page, pageSizeNew, 8);
	     model.addObject("listTravelNew", listTravelNew);
	     List<New> hotTravelNew = newDAO.getHotNew(8); 
	     model.addObject("hotTravelNew", hotTravelNew);
	     model.setViewName("user/travel");
	     return model;
	 }
}
