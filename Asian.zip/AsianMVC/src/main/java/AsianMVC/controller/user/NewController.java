package AsianMVC.controller.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import AsianMVC.dao.Impl.CommentDAO;
import AsianMVC.dao.Impl.MenuDAO;
import AsianMVC.dao.Impl.NewDAO;
import AsianMVC.model.Comment;
import AsianMVC.model.Menu;
import AsianMVC.model.New;


@Controller
public class NewController {

	@Autowired
	private MenuDAO menuDAO;

	@Autowired
	private NewDAO newDAO;
	
	@Autowired
	private CommentDAO commentDAO;

	@RequestMapping(value = { "/newdetails/{new_id}" }, method = RequestMethod.GET)
	public ModelAndView newIndex(ModelAndView model, @PathVariable("new_id") int new_id) {
		List<Menu> listMenu = menuDAO.getAll();
		model.addObject("listMenu", listMenu);

		New detailsNew = newDAO.get(new_id);
		model.addObject("detailsNew", detailsNew);
		
		int currentCategoryId = detailsNew.getCategory().getCategory_id();
		List<New> recentPosts = newDAO.getRecentNew(new_id, currentCategoryId);
	    model.addObject("recentPosts", recentPosts);
	    
	    List<Comment> comments = commentDAO.getCommentsByNewId(new_id);
	    model.addObject("comments", comments);
	    model.addObject("totalComments", comments.size());

		model.setViewName("user/newdetails");
		return model;
	}
	
	@RequestMapping(value = { "/newdetails/{new_id}/comment" }, method = RequestMethod.POST)
	public ModelAndView saveComment(ModelAndView model, @ModelAttribute("comment") Comment comment, RedirectAttributes redirectAttributes, @PathVariable("new_id") int new_id) {
		comment.setNew_id(new_id);
		comment.setStatus("Hiện");
	    commentDAO.saveComment(comment);
	    model.setViewName("redirect:/newdetails/" + new_id);
	    return model;
	}
	
	@RequestMapping(value = {"/newdetails/{new_id}/comment/{comment_id}/edit"}, method = RequestMethod.GET)
	public ModelAndView editComment(@PathVariable("new_id") int new_id, @PathVariable("comment_id") int comment_id) {
	    Comment comment = commentDAO.getCommentById(comment_id);
	    ModelAndView model = new ModelAndView("/edit-comment");
	    model.addObject("comment", comment);
	    model.addObject("new_id", new_id);
	    return model;
	}

	
	@RequestMapping(value = {"/newdetails/{new_id}/comment/{comment_id}/edit"}, method = RequestMethod.POST)
	public ModelAndView updateComment(ModelAndView model, @ModelAttribute Comment comment, @PathVariable("new_id") int new_id, @PathVariable("comment_id") int comment_id) {
	    comment.setComment_id(comment_id);
	    comment.setNew_id(new_id);
	    commentDAO.updateComment(comment); 
	    model.setViewName("redirect:/newdetails/" + new_id);
	    return model;
	}
	
	@RequestMapping(value = {"/newdetails/{new_id}/comment/{comment_id}/delete"}, method = RequestMethod.GET)
	public ModelAndView deleteComment(ModelAndView model, @PathVariable("new_id") int new_id, @PathVariable("comment_id") int comment_id) {
	    commentDAO.deleteComment(comment_id);
	    model.setViewName("redirect:/newdetails/" + new_id);
	    return model;
	}


}
