package AsianMVC.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import AsianMVC.dao.Impl.UserDAO;
import AsianMVC.model.User;

public class UserDAOImpl implements UserDAO{

private JdbcTemplate jdbcTemplate;
	
	public UserDAOImpl(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	@Override
	public User get(String user_name) {
		String sql = "SELECT * FROM tbl_user WHERE user_name = ?";
        try {
            return jdbcTemplate.queryForObject(sql, new Object[]{user_name}, new RowMapper<User>() {
                @Override
                public User mapRow(ResultSet rs, int rowNum) throws SQLException {
                    return new User(rs.getInt("user_id"), rs.getString("user_name"), rs.getString("password"), rs.getString("role"));
                }
            });
        } catch (Exception e) {
            return null; 
        }
    }
}
