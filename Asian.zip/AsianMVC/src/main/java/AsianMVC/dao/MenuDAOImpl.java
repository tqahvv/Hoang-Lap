package AsianMVC.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import AsianMVC.dao.Impl.MenuDAO;
import AsianMVC.model.Menu;

public class MenuDAOImpl implements MenuDAO{
	
	private JdbcTemplate jdbcTemplate;
	
	public MenuDAOImpl(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<Menu> getAll() {
		 String sql = "SELECT * FROM tbl_menu";
		 
		 RowMapper<Menu> rowMapper = new RowMapper<Menu>() {
			
			@Override
			public Menu mapRow(ResultSet rs, int rowNum) throws SQLException {
				Menu menu = new Menu();
	            menu.setMenu_id(rs.getInt("menu_id"));
	            menu.setMenu_name(rs.getString("menu_name"));
	            menu.setUrl(rs.getString("url"));
	            menu.setParent_id(rs.getInt("parent_id"));
	            menu.setOrder(rs.getInt("order"));	            
	            return menu;
			}
		};
		 return jdbcTemplate.query(sql, rowMapper);
	}

	@Override
	public Menu get(Integer menu_id) {
		String sql = "SELECT * FROM tbl_menu WHERE menu_id = " + menu_id;
		ResultSetExtractor<Menu> extractor = new ResultSetExtractor<Menu>() {
			
			@Override
			public Menu extractData(ResultSet rs) throws SQLException, DataAccessException {
				if(rs.next()) {
					String menu_name = rs.getString("menu_name");
					String url = rs.getString("url");
					Integer parent_id = rs.getInt("parent_id");
					Integer order = rs.getInt("order");
					return new Menu(menu_id, menu_name, url, parent_id, order);
				}
				return null;
			}
		};
		return jdbcTemplate.query(sql, extractor);
	}

	@Override
	public int save(Menu menu) {
	    String sql = "INSERT INTO tbl_menu (menu_name, url, parent_id, `order`) VALUES (?, ?, ?, ?);";
	    return jdbcTemplate.update(sql, menu.getMenu_name(), menu.getUrl(), menu.getParent_id(), menu.getOrder());
	}

	@Override
	public int update(Menu menu) {
	    String sql = "UPDATE tbl_menu SET menu_name=?, url=?, parent_id=?, `order`=? WHERE menu_id=?";
	    return jdbcTemplate.update(sql, menu.getMenu_name(), menu.getUrl(), menu.getParent_id(), menu.getOrder(), menu.getMenu_id());
	}

	@Override
	public int delete(Integer menu_id) {
		String sql = "DELETE FROM tbl_menu WHERE menu_id =" + menu_id;
		return jdbcTemplate.update(sql);
	}
	
}
