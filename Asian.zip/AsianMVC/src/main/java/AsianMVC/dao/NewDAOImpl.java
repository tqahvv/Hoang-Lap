	package AsianMVC.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import AsianMVC.dao.Impl.NewDAO;
import AsianMVC.model.Category;
import AsianMVC.model.New;

public class NewDAOImpl implements NewDAO {
	
	private JdbcTemplate jdbcTemplate;

	public NewDAOImpl(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<New> getAll(int page, int pageSizeNew, Integer category_id) {	    
	    String sql = "SELECT n.new_id, n.new_title, n.new_image, n.new_caption, n.new_content, n.new_hot, n.status, " +
	                 "c.category_id, c.category_name, c.category_group " +
	                 "FROM asian.tbl_new n " +
	                 "INNER JOIN asian.tbl_category c ON c.category_id = n.category_id "+
	                 "WHERE c.category_id = ? AND n.status = 'Hiện' ORDER BY n.new_id DESC LIMIT ? OFFSET ?";	    

	    int offset = (page - 1) * pageSizeNew;

	    RowMapper<New> rowMapper = (rs, rowNum) -> {
	        Category category = new Category(
	            rs.getInt("category_id"),
	            rs.getString("category_name"),
	            rs.getString("category_group")
	        );
	        return new New(
	            rs.getInt("new_id"),
	            rs.getString("new_title"),
	            rs.getString("new_image"),
	            rs.getString("new_caption"),
	            rs.getString("new_content"),
	            rs.getString("new_hot"),
	            rs.getString("status"),
	            category
	        );
	    };
	    return jdbcTemplate.query(sql, new Object[]{category_id, pageSizeNew, offset}, rowMapper);
	}


	@Override
	public List<New> getHotNew(Integer category_id) {
	    String sql = "SELECT n.new_id, n.new_title, n.new_image, n.new_caption, n.new_content, n.new_hot, n.status, " +
	                 "c.category_id, c.category_name, c.category_group " +
	                 "FROM asian.tbl_new n " +
	                 "INNER JOIN asian.tbl_category c ON c.category_id = n.category_id " +
	                 "WHERE n.new_hot = 'hot' AND c.category_id = ? " +
	                 "ORDER BY n.new_id DESC LIMIT 1";

	    RowMapper<New> rowMapper = (rs, rowNum) -> {
	        Category category = new Category(
	            rs.getInt("category_id"),
	            rs.getString("category_name"),
	            rs.getString("category_group")
	        );
	        return new New(
	            rs.getInt("new_id"),
	            rs.getString("new_title"),
	            rs.getString("new_image"),
	            rs.getString("new_caption"),
	            rs.getString("new_content"),
	            rs.getString("new_hot"),
	            rs.getString("status"),
	            category
	        );
	    };

	    return jdbcTemplate.query(sql, new Object[]{category_id}, rowMapper);
	}


	@Override
	public New get(Integer new_id) {
		String sql = "SELECT n.new_id, n.new_title, n.new_image, n.new_caption, n.new_content, n.new_hot, n.status, c.category_id, c.category_name FROM asian.tbl_new n\r\n"
				+ "INNER JOIN asian.tbl_category c ON c.category_id = n.category_id WHERE n.new_id = ?";
		
		return jdbcTemplate.queryForObject(sql, new Object[]{new_id}, (rs, rowNum) -> {
	        New news = new New();
	        news.setNew_id(rs.getInt("new_id"));
	        news.setNew_title(rs.getString("new_title"));
	        news.setNew_image(rs.getString("new_image"));
	        news.setNew_caption(rs.getString("new_caption"));
	        news.setNew_content(rs.getString("new_content"));
	        news.setNew_hot(rs.getString("new_hot"));
	        news.setStatus(rs.getString("status"));

	        Category category = new Category();
	        category.setCategory_id(rs.getInt("category_id"));
	        category.setCategory_name(rs.getString("category_name"));

	        news.setCategory(category);

	        return news;
	    });
	}

	@Override
	public int getTotalNew() {
		String sql = "SELECT COUNT(*) FROM tbl_new";
		return jdbcTemplate.queryForObject(sql, Integer.class);
	}

	@Override
	public int save(New news) {
		Category category = news.getCategory();
		if(category.getCategory_id() == null) {
			String sqlCate = "INSERT INTO tbl_category(category_name, category_group) VALUES (?,?);";
			jdbcTemplate.update(sqlCate, category.getCategory_name(), category.getCategory_group());
			
			String sqlCateId = "SELECT LAST_INSERT_ID()";
			int categoryId = jdbcTemplate.queryForObject(sqlCateId, Integer.class);
			category.setCategory_id(categoryId);
		}
		String sql = "INSERT INTO tbl_new(new_title, new_image, new_caption, new_content, new_hot, status, category_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
		return jdbcTemplate.update(sql, news.getNew_title(), news.getNew_image(), news.getNew_caption(), news.getNew_content(), news.getNew_hot(), news.getStatus(), category.getCategory_id());
	}

	@Override
	public int update(New news) {
	    String sql = "UPDATE tbl_new SET new_title = ?, new_image = ?, new_caption = ?, new_content = ?, new_hot = ?, status = ?, category_id = ? WHERE new_id = ?";
	    return jdbcTemplate.update(sql, news.getNew_title(), news.getNew_image(), news.getNew_caption(), news.getNew_content(), news.getNew_hot(), news.getStatus(), news.getCategory() != null ? news.getCategory().getCategory_id() : null, news.getNew_id());
	}

	@Override
	public int delete(Integer new_id) {
		String sql = "DELETE FROM tbl_new WHERE new_id=" + new_id;
		return jdbcTemplate.update(sql);
	}

	@Override
	public List<Category> listCategory() {
		String sql = "SELECT * FROM tbl_category";
		RowMapper<Category> rowMapper = (rs, rowNum) -> {
			Category category = new Category();
			category.setCategory_id(rs.getInt("category_id"));
			category.setCategory_name(rs.getString("category_name"));
			category.setCategory_group(rs.getString("category_group"));
			return category;
		};
		return jdbcTemplate.query(sql, rowMapper);
	}

	@Override
	public List<New> getRecentNew(int currentNewId, int currentCategoryId) {
	    String sql = "SELECT n.new_id, n.new_title, n.new_image, n.new_caption, n.new_content, n.new_hot, n.status, c.category_id, c.category_name, c.category_group " +
	                 "FROM asian.tbl_new n " +
	                 "INNER JOIN asian.tbl_category c ON c.category_id = n.category_id " +
	                 "WHERE n.new_id != ? AND c.category_id = ? " +
	                 "ORDER BY n.new_id DESC LIMIT 5";

	    return jdbcTemplate.query(sql, new Object[] { currentNewId, currentCategoryId }, (rs, rowNum) -> {
	        Category category = new Category(rs.getInt("category_id"), rs.getString("category_name"), rs.getString("category_group"));
	        return new New(
	            rs.getInt("new_id"),
	            rs.getString("new_title"),
	            rs.getString("new_image"),
	            rs.getString("new_caption"),
	            rs.getString("new_content"),
	            rs.getString("new_hot"),
	            rs.getString("status"),
	            category
	        );
	    });
	}

	@Override
	public List<New> getAllNew(int page, int pageSizeNew) {
		String sql = "SELECT n.new_id, n.new_title, n.new_image, n.new_caption, n.new_content, n.new_hot, n.status, " +
                "c.category_id, c.category_name, c.category_group " +
                "FROM asian.tbl_new n " +
                "INNER JOIN asian.tbl_category c ON c.category_id = n.category_id ORDER BY n.new_id DESC LIMIT ? OFFSET ?";

   int offset = (page - 1) * pageSizeNew;

   RowMapper<New> rowMapper = (rs, rowNum) -> {
       Category category = new Category(
           rs.getInt("category_id"),
           rs.getString("category_name"),
           rs.getString("category_group")
       );
       return new New(
           rs.getInt("new_id"),
           rs.getString("new_title"),
           rs.getString("new_image"),
           rs.getString("new_caption"),
           rs.getString("new_content"),
           rs.getString("new_hot"),
           rs.getString("status"),
           category
       );
   };
   return jdbcTemplate.query(sql, new Object[]{pageSizeNew, offset}, rowMapper);
	}
	
	@Override
	public List<New> getAllIn(int page, int pageSizeNew, Integer category_id) {	    
	    String sql = "SELECT n.new_id, n.new_title, n.new_image, n.new_caption, n.new_content, n.new_hot, n.status, " +
	                 "c.category_id, c.category_name, c.category_group " +
	                 "FROM asian.tbl_new n " +
	                 "INNER JOIN asian.tbl_category c ON c.category_id = n.category_id "+
	                 "WHERE c.category_id = ? ORDER BY n.new_id DESC LIMIT ? OFFSET ?";	    

	    int offset = (page - 1) * pageSizeNew;

	    RowMapper<New> rowMapper = (rs, rowNum) -> {
	        Category category = new Category(
	            rs.getInt("category_id"),
	            rs.getString("category_name"),
	            rs.getString("category_group")
	        );
	        return new New(
	            rs.getInt("new_id"),
	            rs.getString("new_title"),
	            rs.getString("new_image"),
	            rs.getString("new_caption"),
	            rs.getString("new_content"),
	            rs.getString("new_hot"),
	            rs.getString("status"),
	            category
	        );
	    };
	    return jdbcTemplate.query(sql, new Object[]{category_id, pageSizeNew, offset}, rowMapper);
	}
	
	@Override
	public List<New> getNewsByCategoryAndKeyword(int page, int pageSizeNew, Integer category_id, String keyword) {
	    String sql = "SELECT n.new_id, n.new_title, n.new_image, n.new_caption, n.new_content, n.new_hot, n.status, " +
	                 "c.category_id, c.category_name, c.category_group " +
	                 "FROM asian.tbl_new n " +
	                 "INNER JOIN asian.tbl_category c ON c.category_id = n.category_id " +
	                 "WHERE c.category_id = ? AND n.new_title LIKE ? ORDER BY n.new_id DESC LIMIT ? OFFSET ?";

	    int offset = (page - 1) * pageSizeNew;
	    
	    RowMapper<New> rowMapper = (rs, rowNum) -> {
	        Category category = new Category(
	            rs.getInt("category_id"),
	            rs.getString("category_name"),
	            rs.getString("category_group")
	        );
	        return new New(
	            rs.getInt("new_id"),
	            rs.getString("new_title"),
	            rs.getString("new_image"),
	            rs.getString("new_caption"),
	            rs.getString("new_content"),
	            rs.getString("new_hot"),
	            rs.getString("status"),
	            category
	        );
	    };
	    return jdbcTemplate.query(sql, new Object[]{category_id, "%" + keyword + "%", pageSizeNew, offset}, rowMapper);
	}

	@Override
	public List<New> getNewsByKeyword(int page, int pageSizeNew, String keyword) {
	    String sql = "SELECT n.new_id, n.new_title, n.new_image, n.new_caption, n.new_content, n.new_hot, n.status, " +
	                 "c.category_id, c.category_name, c.category_group " +
	                 "FROM asian.tbl_new n " +
	                 "INNER JOIN asian.tbl_category c ON c.category_id = n.category_id " +
	                 "WHERE n.new_title LIKE ? ORDER BY n.new_id DESC LIMIT ? OFFSET ?";

	    int offset = (page - 1) * pageSizeNew;
	    RowMapper<New> rowMapper = (rs, rowNum) -> {
	        Category category = new Category(
	            rs.getInt("category_id"),
	            rs.getString("category_name"),
	            rs.getString("category_group")
	        );
	        return new New(
	            rs.getInt("new_id"),
	            rs.getString("new_title"),
	            rs.getString("new_image"),
	            rs.getString("new_caption"),
	            rs.getString("new_content"),
	            rs.getString("new_hot"),
	            rs.getString("status"),
	            category
	        );
	    };
	    return jdbcTemplate.query(sql, new Object[]{"%" + keyword + "%", pageSizeNew, offset}, rowMapper);
	}

	
	@Override
	public int getTotalNewByCategory(Integer category_id) {
	    String sql;
	    Object[] params;

	    if (category_id != null) {
	        sql = "SELECT COUNT(*) FROM asian.tbl_new WHERE category_id = ?";
	        params = new Object[]{category_id};
	    } else {
	        sql = "SELECT COUNT(*) FROM asian.tbl_new";
	        params = new Object[]{};
	    }

	    return jdbcTemplate.queryForObject(sql, params, Integer.class);
	}

	@Override
	public int getTotalNewsByKeyword(String keyword) {
	    String sql = "SELECT COUNT(*) FROM asian.tbl_new " +
	                 "WHERE new_title LIKE ? OR new_content LIKE ?";
	    String queryKeyword = "%" + keyword + "%";
	    return jdbcTemplate.queryForObject(sql, new Object[]{queryKeyword, queryKeyword}, Integer.class);
	}

	@Override
	public int getTotalNewsByCategoryAndKeyword(int category_id, String keyword) {
	    String sql = "SELECT COUNT(*) FROM asian.tbl_new n " +
	                 "INNER JOIN asian.tbl_category c ON c.category_id = n.category_id " +
	                 "WHERE c.category_id = ? AND (n.new_title LIKE ? OR n.new_content LIKE ?)";
	    String queryKeyword = "%" + keyword + "%";
	    return jdbcTemplate.queryForObject(sql, new Object[]{category_id, queryKeyword, queryKeyword}, Integer.class);
	}

	@Override
	public Map<String, Integer> countNewByCategory() {
	    String sql = "SELECT c.category_name, COUNT(n.new_id) AS new_count " +
	                 "FROM tbl_category c " +
	                 "LEFT JOIN tbl_new n ON c.category_id = n.category_id " +
	                 "GROUP BY c.category_id";

	    return jdbcTemplate.query(sql, rs -> {
	        Map<String, Integer> result = new HashMap<>();
	        while (rs.next()) {
	            result.put(rs.getString("category_name"), rs.getInt("new_count"));
	        }
	        return result;
	    });
	}
	
	@Override
	public void updateNewStatus(Integer new_id, String status) {
		String sql = "UPDATE tbl_new SET status = ? WHERE new_id = ?";
		jdbcTemplate.update(sql, status, new_id);
	}

}
