package AsianMVC.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import AsianMVC.dao.Impl.CategoryDAO;
import AsianMVC.model.Category;

public class CategoryDAOImpl implements CategoryDAO{
	
	private JdbcTemplate jdbcTemplate;
	
	public CategoryDAOImpl(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<Category> getAll() {
		String sql = "SELECT * FROM tbl_category";
		RowMapper<Category> rowMapper = new RowMapper<Category>() {
			
			@Override
			public Category mapRow(ResultSet rs, int rowNum) throws SQLException {
				Category category = new Category();
				category.setCategory_id(rs.getInt("category_id"));
				category.setCategory_name(rs.getString("category_name"));
				category.setCategory_group(rs.getString("category_group"));
				return category;
			}
		};
		return jdbcTemplate.query(sql, rowMapper);
	}

	@Override
	public Category get(Integer category_id) {
		String sql = "SELECT * FROM tbl_category WHERE category_id =" + category_id;
		ResultSetExtractor<Category> extractor = new ResultSetExtractor<Category>() {
			
			@Override
			public Category extractData(ResultSet rs) throws SQLException, DataAccessException {
				if(rs.next()) {
					String category_name = rs.getString("category_name");
					String category_group = rs.getString("category_group");
					
					return new Category(category_id, category_name, category_group);
				}
				return null;
			}
		}; 
		return jdbcTemplate.query(sql, extractor);
	}

	@Override
	public int save(Category category) {
		String sql = "INSERT INTO tbl_category(category_name, category_group) VALUES(?, ?)";
		return jdbcTemplate.update(sql, category.getCategory_name(), category.getCategory_group());
	}

	@Override
	public int update(Category category) {
		String sql = "UPDATE tbl_category SET category_name=?, category_group=? WHERE category_id=?";
		return jdbcTemplate.update(sql, category.getCategory_name(), category.getCategory_group(), category.getCategory_id());
	}

	@Override
	public int delete(Integer category_id) {
		String sql = "DELETE FROM tbl_category WHERE category_id=" + category_id;
		return jdbcTemplate.update(sql);
	}

}
