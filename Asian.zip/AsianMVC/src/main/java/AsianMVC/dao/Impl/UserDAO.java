package AsianMVC.dao.Impl;

import AsianMVC.model.User;

public interface UserDAO {
	public User get(String user_name);
}
