package AsianMVC.dao.Impl;

import java.util.List;

import AsianMVC.model.Menu;

public interface MenuDAO {
	public List<Menu> getAll();
	
	public Menu get(Integer menu_id);
	
	public int save(Menu menu);
	
	public int update(Menu menu);
	
	public int delete(Integer menu_id);
}
