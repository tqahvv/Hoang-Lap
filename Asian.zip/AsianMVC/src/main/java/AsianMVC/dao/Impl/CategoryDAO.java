package AsianMVC.dao.Impl;

import java.util.List;

import AsianMVC.model.Category;

public interface CategoryDAO {
	public List<Category> getAll();
	
	public Category get(Integer category_id);
	
	public int save(Category category);
	
	public int update(Category category);
	
	public int delete(Integer category_id);
}
