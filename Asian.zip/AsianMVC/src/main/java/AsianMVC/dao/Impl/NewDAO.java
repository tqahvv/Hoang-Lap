package AsianMVC.dao.Impl;

import java.util.List;
import java.util.Map;

import AsianMVC.model.Category;
import AsianMVC.model.New;

public interface NewDAO {
	public List<New> getAll(int page, int pageSizeNew, Integer category_id);	
	
	public List<New> getAllNew(int page, int pageSizeNew);
	
	public List<New> getAllIn(int page, int pageSizeNew, Integer category_id);
	
	public List<New> getHotNew(Integer category_id);
	
	public New get(Integer new_id);
	
	public int getTotalNew();
	
	public int save(New news);
	
	public int update(New news);
	
	public int delete(Integer new_id);
	
	public List<Category> listCategory();
	
	public List<New> getRecentNew(int currentNewId, int currentCategoryId);
	
	public int getTotalNewByCategory(Integer category_id);
	
	public List<New> getNewsByCategoryAndKeyword(int page, int pageSizeNew, Integer category_id, String keyword);
	
	public List<New> getNewsByKeyword(int page, int pageSizeNew, String keyword);
	
	public int getTotalNewsByKeyword(String keyword);
	
	public int getTotalNewsByCategoryAndKeyword(int category_id, String keyword);
	
	public Map<String, Integer> countNewByCategory();
	
	public void updateNewStatus(Integer new_id, String status);
}
