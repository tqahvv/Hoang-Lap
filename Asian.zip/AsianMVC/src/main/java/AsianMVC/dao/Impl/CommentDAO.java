package AsianMVC.dao.Impl;

import java.util.List;

import AsianMVC.model.Comment;

public interface CommentDAO {
	public List<Comment> getCommentsByNewId(int new_id);
	
	public int saveComment(Comment comment);
	
	public Comment getCommentById(int comment_id);
	
	public int updateComment(Comment comment);
	
	public int deleteComment(Integer comment_id);
	
	public List<Comment> getAll();
	
	public List<Comment> getCategoryByKeyword(String keyword);
	
	public List<Comment> getCategoryByKeywordAndDate(String keyword, String date);
	
	public List<Comment> getCommentsByDate(String date);
	
	public void updateCommentStatus(Integer comment_id, String status);
}
