package AsianMVC.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import AsianMVC.dao.Impl.CommentDAO;
import AsianMVC.model.Comment;

public class CommentDAOImpl implements CommentDAO{

	private JdbcTemplate jdbcTemplate;
	
	public CommentDAOImpl(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public List<Comment> getCommentsByNewId(int new_id) {
		String sql = "SELECT * FROM tbl_comment WHERE new_id = ? AND status = 'Hiện' ORDER BY comment_id DESC";
		return jdbcTemplate.query(sql, new Object[]{new_id}, new BeanPropertyRowMapper<>(Comment.class));
	}

	@Override
	public int saveComment(Comment comment) {
	    String sql = "INSERT INTO tbl_comment (name, email, comment, new_id, created_date, status) VALUES (?, ?, ?, ?, NOW(), ?)";
	    return jdbcTemplate.update(sql, comment.getName(), comment.getEmail(), comment.getComment(), comment.getNew_id(), comment.getStatus());
	}

	@Override
	public Comment getCommentById(int comment_id) {
	    String sql = "SELECT * FROM tbl_comment WHERE comment_id = ?";
	    return jdbcTemplate.queryForObject(sql, new Object[]{comment_id}, new BeanPropertyRowMapper<>(Comment.class));
	}

	@Override
	public int updateComment(Comment comment) {
	    String sql = "UPDATE tbl_comment SET name = ?, email = ?, comment = ?, created_date = NOW(), status = ? WHERE comment_id = ?";
	    return jdbcTemplate.update(sql, comment.getName(), comment.getEmail(), comment.getComment(), comment.getStatus(), comment.getComment_id());
	}

	@Override
	public int deleteComment(Integer comment_id) {
	    String sql = "DELETE FROM tbl_comment WHERE comment_id = ?";
	    return jdbcTemplate.update(sql, comment_id);
	}
	
	@Override
	public List<Comment> getAll(){
		String sql = "SELECT c.*, n.new_title, n.new_image FROM asian.tbl_comment c \r\n"
				+ "INNER JOIN asian.tbl_new n ON n.new_id = c.new_id ORDER BY c.comment_id DESC";
		RowMapper<Comment> rowMapper = new RowMapper<Comment>() {
			
			@Override
			public Comment mapRow(ResultSet rs, int rowNum) throws SQLException {
				Comment comment = new Comment();
				comment.setComment_id(rs.getInt("comment_id"));
				comment.setName(rs.getString("name"));
				comment.setEmail(rs.getString("email"));
				comment.setComment(rs.getString("comment"));
				comment.setNew_id(rs.getInt("new_id"));
				comment.setCreated_date(rs.getDate("created_date"));
				comment.setStatus(rs.getString("status"));
				comment.setNew_title(rs.getString("new_title"));
				comment.setNew_image(rs.getString("new_image"));
				return comment;
			}
		};
		return jdbcTemplate.query(sql, rowMapper);
	}

	@Override
	public List<Comment> getCategoryByKeyword(String keyword) {
		String sql = "SELECT c.*, n.new_title, n.new_image FROM tbl_comment c INNER JOIN tbl_new n ON n.new_id = c.new_id "
		           + "WHERE n.new_title LIKE ? ORDER BY c.created_date DESC";
		RowMapper<Comment> rowMapper = new RowMapper<Comment>() {
			
			@Override
			public Comment mapRow(ResultSet rs, int rowNum) throws SQLException {
				Comment comment = new Comment();
				comment.setComment_id(rs.getInt("comment_id"));
				comment.setName(rs.getString("name"));
				comment.setEmail(rs.getString("email"));
				comment.setComment(rs.getString("comment"));
				comment.setNew_id(rs.getInt("new_id"));
				comment.setCreated_date(rs.getDate("created_date"));
				comment.setStatus(rs.getString("status"));
				comment.setNew_title(rs.getString("new_title"));
				comment.setNew_image(rs.getString("new_image"));
				return comment;
			}
		};
		return jdbcTemplate.query(sql, new Object[] {"%" + keyword + "%"}, rowMapper);
	}
	
	@Override
	public List<Comment> getCategoryByKeywordAndDate(String keyword, String date) {
	    String sql = "SELECT c.*, n.new_title, n.new_image FROM tbl_comment c INNER JOIN tbl_new n ON n.new_id = c.new_id "
	               + "WHERE n.new_title LIKE ? AND DATE(c.created_date) = ? ORDER BY c.created_date DESC";
	    RowMapper<Comment> rowMapper = new RowMapper<Comment>() {

	        @Override
	        public Comment mapRow(ResultSet rs, int rowNum) throws SQLException {
	            Comment comment = new Comment();
	            comment.setComment_id(rs.getInt("comment_id"));
	            comment.setName(rs.getString("name"));
	            comment.setEmail(rs.getString("email"));
	            comment.setComment(rs.getString("comment"));
	            comment.setNew_id(rs.getInt("new_id"));
	            comment.setCreated_date(rs.getDate("created_date"));
	            comment.setStatus(rs.getString("status"));
	            comment.setNew_title(rs.getString("new_title"));
	            comment.setNew_image(rs.getString("new_image"));
	            return comment;
	        }
	    };
	    return jdbcTemplate.query(sql, new Object[] { "%" + keyword + "%", date }, rowMapper);
	}

	@Override
	public List<Comment> getCommentsByDate(String date) {
	    String sql = "SELECT c.*, n.new_title, n.new_image FROM tbl_comment c INNER JOIN tbl_new n ON n.new_id = c.new_id "
	               + "WHERE DATE(c.created_date) = ? ORDER BY c.created_date DESC";
	    RowMapper<Comment> rowMapper = new RowMapper<Comment>() {

	        @Override
	        public Comment mapRow(ResultSet rs, int rowNum) throws SQLException {
	            Comment comment = new Comment();
	            comment.setComment_id(rs.getInt("comment_id"));
	            comment.setName(rs.getString("name"));
	            comment.setEmail(rs.getString("email"));
	            comment.setComment(rs.getString("comment"));
	            comment.setNew_id(rs.getInt("new_id"));
	            comment.setCreated_date(rs.getDate("created_date"));
	            comment.setStatus(rs.getString("status"));
	            comment.setNew_title(rs.getString("new_title"));
	            comment.setNew_image(rs.getString("new_image"));
	            return comment;
	        }
	    };
	    return jdbcTemplate.query(sql, new Object[] { date }, rowMapper);
	}

	@Override
	public void updateCommentStatus(Integer comment_id, String status) {
		String sql = "UPDATE tbl_comment SET status = ? where comment_id = ?";
		jdbcTemplate.update(sql, status, comment_id);
	}
}
